package com.app.axzifserviceboy.DashBoad;

import static android.content.Context.MODE_PRIVATE;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.app.axzifserviceboy.Model.Data;
import com.app.axzifserviceboy.R;
import com.app.axzifserviceboy.Utils.ApplicationConstant;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;

import de.hdodenhof.circleimageview.CircleImageView;


public class ProfileFragment extends Fragment {
    String secureloginResponse;
    Data securelogincheckResponse;
    TextView name, contact,email,address;
    CircleImageView profilerimg;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_profile, container, false);
        GETid(v);
        return v;
    }

    public void GETid(View v)
    {
        name = v.findViewById(R.id.name);
        profilerimg = v.findViewById(R.id.profilerimg);
        email = v.findViewById(R.id.email);
        contact = v.findViewById(R.id.contact);
        address = v.findViewById(R.id.address);
            SharedPreferences myPreferences = getActivity().getSharedPreferences(ApplicationConstant.INSTANCE.prefNamePref, MODE_PRIVATE);
            secureloginResponse = myPreferences.getString(ApplicationConstant.INSTANCE.Loginrespose, null);
            securelogincheckResponse = new Gson().fromJson(secureloginResponse, Data.class);
            name.setText(securelogincheckResponse.getName());
            contact.setText(securelogincheckResponse.getMobile());
            email.setText(securelogincheckResponse.getEmail());
            address.setText(securelogincheckResponse.getAddress1());
           Glide.with(getActivity())
                .load(securelogincheckResponse.getIcon_img())
                .placeholder(R.drawable.logo1)
                .fitCenter()
                .into(profilerimg);
    }
}