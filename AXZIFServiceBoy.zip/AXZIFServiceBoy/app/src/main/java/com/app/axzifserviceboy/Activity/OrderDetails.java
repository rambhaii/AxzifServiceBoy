package com.app.axzifserviceboy.Activity;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.app.axzifserviceboy.Model.Datum;
import com.app.axzifserviceboy.R;
import com.google.gson.Gson;

public class OrderDetails extends AppCompatActivity {
    AppCompatButton calling_btn;
    Button order_status_btn;
    TextView order_id,cust_name,p_name,customer_phone,pay_status,pay_type;
    TextView date;
    String data;
    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_details);
        data=getIntent().getStringExtra("data");
        Datum datum=new Gson().fromJson(data, Datum.class);
        order_id=findViewById(R.id.order_id);
        order_id.setText(datum.getOrder_id());
        date=findViewById(R.id.date);
        date.setText(datum.getDelivery_date());
        cust_name=findViewById(R.id.cust_name);
        cust_name.setText(datum.getName());
        customer_phone=findViewById(R.id.customer_phone);
        customer_phone.setText(datum.getMobile());
        p_name=findViewById(R.id.p_name);
        p_name.setText(datum.getProduct_name());
        pay_status=findViewById(R.id.pay_status);
        pay_status.setText(datum.getPayment_status());
        order_status_btn=findViewById(R.id.order_status_btn);
        order_status_btn.setText(datum.getOrder_status());
        pay_type=findViewById(R.id.pay_type);
        pay_type.setText(datum.getPayment_type());
        calling_btn=findViewById(R.id.calling_btn);
        calling_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:9423527107"));
                startActivity(intent);
            }
        });
    }
}