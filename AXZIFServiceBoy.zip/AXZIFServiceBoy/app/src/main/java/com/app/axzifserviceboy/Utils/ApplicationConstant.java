package com.app.axzifserviceboy.Utils;

public enum ApplicationConstant {
    INSTANCE;
    public String baseUrl="http://axzif.com";
    public String Headertoken = "api@parthshopping.com";
    public String prefNamePref = "prefNamePref";
    public String Loginrespose = "Loginrespose";
    public String list = "list";
    public String one = "one";
}
