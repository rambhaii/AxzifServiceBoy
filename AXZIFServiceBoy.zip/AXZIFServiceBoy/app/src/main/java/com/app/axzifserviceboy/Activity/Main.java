package com.app.axzifserviceboy.Activity;

public class Main {
    public static void main(String[] args) {
        int i = Integer.parseInt(null);
        System.out.println(i);
    }
}
