package com.app.axzifserviceboy.Utils;

import com.app.axzifserviceboy.Model.MyResponse;
import com.app.axzifserviceboy.Model.ResponseList;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Header;
import retrofit2.http.POST;

public interface AllAPIs
{

    @FormUrlEncoded
    @POST("/api/Delivery_boy/login_deliver_boy")
    Call<MyResponse> signIn(@Header("X-API-KEY") String authorization,
                            @Field("email") String email,
                            @Field("password") String password


    );

    @FormUrlEncoded
    @POST("/api/Delivery_boy/GetassignorderBydeliveryboyid")
    Call<ResponseList> listServices(@Header("X-API-KEY") String authorization,
                                    @Field("delivery_boy_id") String delivery_boy_id,
                                    @Field("status") String status,
                                    @Field("date") String date


    );

  @FormUrlEncoded
  @POST("/api/Delivery_boy/UpdateAssignstatus")
  Call<ResponseList> UpdateStatus(@Header("X-API-KEY") String authorization,
                          @Field("delivery_boy_id") String delivery_boy_id,
                          @Field("status") String status,
                          @Field("order_id") String order_id
  );


@FormUrlEncoded
@POST("/api/Delivery_boy/Sendotp")
Call<MyResponse> SendOtp(@Header("X-API-KEY") String authorization,
                                @Field("order_id") String order_id

);


@FormUrlEncoded
@POST("/api/Delivery_boy/VerifyOtp")
Call<ResponseList> verify(@Header("X-API-KEY") String authorization,
                           @Field("order_id") String order_id,
                           @Field("payment_type") String payment_type,
                           @Field("otp") String otp

);


}
